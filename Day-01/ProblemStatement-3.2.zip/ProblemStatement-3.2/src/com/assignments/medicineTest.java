package com.assignments;

public class medicineTest 
{
public static void main(String[] args) 
{
medicine m[] = new medicine[5];
double i = Math.random()*4;
int j = (int) i;
System.out.println(j);
switch(j){

case 1: m[1] = new medicine();
m[0] = new Tablet();
m[1].displayLabel();
m[0].displayLabel();
break;
case 2: m[2] = new medicine();
m[1] = new Syrup();
m[2].displayLabel();
m[1].displayLabel();
break;
case 3: m[3] = new medicine();
m[2] = new Ointment();
m[3].displayLabel();
m[2].displayLabel();
break;
default: System.out.println("Invalid Choice");
}
}
}
