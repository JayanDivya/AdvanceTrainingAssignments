import java.util.Scanner;

class Main {
  public static void main(String[] args) {
     Scanner sc= new Scanner(System.in);
     System.out.println("Enter the i value:");
    int i = sc.nextInt();
    System.out.println("Enter the n value:");
    int n = sc.nextInt();
    System.out.println("Enter the no.of terms:");
    int b = sc.nextInt();
    System.out.println("Fibonacci Series untill " + b + " terms is:");

    for(int a=i;a<=b;a++) {
      System.out.print(i + ", ");

      int nextTerm = i + n;
      i = n;
      n = nextTerm;
    }
  }
}