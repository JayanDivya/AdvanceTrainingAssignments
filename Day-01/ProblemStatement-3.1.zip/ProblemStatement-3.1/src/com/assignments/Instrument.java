package com.assignments;

public abstract class Instrument {
	public abstract void play();
}
