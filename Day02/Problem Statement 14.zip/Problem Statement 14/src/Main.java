import java.util.*;
 
public class Main {
    public static void sortedMerge(int a[], int b[],int res[], int n,int m)
                             
    {
        // Concatenation of two arrays
        int i = 0, j = 0, k = 0;
        while (i < n) {
            res[k] = a[i];
            i++;
            k++;
        }
         
        while (j < m) {
            res[k] = b[j];
            j++;
            k++;
        }
     
        // sorting the result array
       Arrays.sort(res);
    }
     
    public static void main(String[] args)
    {
        int a[] = { 10, 5, 15 };
        int b[] = { 20, 3, 2 };
        int n = a.length;
        int m = b.length;
     
        int res[]=new int[n + m];// Final merge list
        sortedMerge(a, b, res, n, m);
     
        System.out.print("Sorted merged list :");
        for (int i = 0; i < n + m; i++)
            System.out.print(" " + res[i]);
        
        
        int a1[] = { 1,10,5,15 };
        int b1[] = { 20, 0, 2};
        int n1 = a1.length;
        int m1 = b1.length;
      
        int res1[] = new int[n1 + m1];// Final merge list
        sortedMerge(a1, b1, res1, n1, m1);
      
        System.out.print("\nSorted merged list :");
        for (int i = 0; i < n1 + m1; i++)
            System.out.print(" " + res1[i]);
    }
}