import java.util.Scanner;
import java.util.Vector;
	  
public class Main {
		static int demo[] = {1, 2, 5, 10, 20, 50, 100, 500, 2000};
	    static int n = demo.length;
	  
	    static void findMin(int V)
	    {
	   	        Vector<Integer> ans = new Vector<>();
	  
	       	   for (int i = n - 1; i >= 0; i--)
	        {
	           
	            while (V >= demo[i]) 
	            {
	                V -= demo[i];
	                ans.add(demo[i]);
	            }
	        }
	  
	        
	        for (int i = 0; i < ans.size(); i++)
	        {
	            System.out.print(" " + ans.elementAt(i));
	                
	            
	        }
	        System.out.println("\nMinimum no.of coins and/or notes needed to make the change of Rs is: "+ans.size());
	    }
	  
	   
	    public static void main(String[] args) 
	    {
	    	 Scanner sc=new Scanner(System.in);
	    	   System.out.println("Enter the Number");
	    	   int n=sc.nextInt();
	        
	    	   
	        System.out.print("Following is minimal number of change for " + n + " Rs: ");
	        findMin(n);
	    }
	}
