package com.assignments;

class LinkedList
{
    Node head; 
 
    class Node {
        int data;
        Node next;
        Node(int d)
        {
            data = d;
            next = null;
        }
    }
 
    
    void getNthFromLast(int n)
    {
        Node main_ptr = head;
        Node ref_ptr = head;
 
        int count = 0;
        if (head != null)
        {
            while (count < n)
            {
                if (ref_ptr == null)
                {
                    System.out.println(n +" is greater than the no of nodes value in the list -1");
                    return;
                }
                ref_ptr = ref_ptr.next;
                count++;
            }
 
            if(ref_ptr == null)
            {
              
              if(head != null)
                System.out.println(n+ " Node value from last is " +head.data);
            }
            else
            {
                   
              while (ref_ptr != null)
              {
                  main_ptr = main_ptr.next;
                  ref_ptr = ref_ptr.next;
              }
              System.out.println(n+" Node value from last is : " +main_ptr.data);
                                
                                  
            }
        }
    }
 
   
    public void add(int new_data)
    {
        
        Node new_node = new Node(new_data);
 
        
        new_node.next = head;
 
        
        head = new_node;
    }
 
   
    public static void main(String[] args)
    {
        LinkedList list = new LinkedList();
        list.add(9);
        list.add(8);
        list.add(7);
        list.add(6);
        list.add(5);
        list.add(4);
        list.add(3);
        list.add(2);
        list.add(1);
        list.getNthFromLast(2);
        
        LinkedList list1 = new LinkedList();
        list1.add(10);
        list1.add(25);
        list1.add(100);
        list1.add(5);
        list1.add(15);
        list1.getNthFromLast(6);
    }
}
//